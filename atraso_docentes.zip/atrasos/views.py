from collections import Counter
from datetime import datetime

from django.conf import settings
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group, User
from django.core import signing
from django.http import HttpResponse
from django.shortcuts import redirect, render

from .permisos import acceso_restringido_atrasos, usuario_tiene_rol_permitido
from .servicios_excel import analizar_excel_en_memoria
from .servicio_reporte import generar_pdf_reporte


@login_required
def acceso_denegado(request):
    contexto = {
        "titulo": "Acceso restringido",
        "mensaje": (
            "Tu usuario inició sesión correctamente, pero no cuenta con permisos "
            "para acceder al sistema de control de atrasos docentes."
        ),
    }
    return render(request, "atrasos/acceso_denegado.html", contexto)


def acceso_token(request):
    token = request.GET.get("token")

    if not token:
        return redirect("/login/?next=/")

    try:
        datos = signing.loads(
            token,
            key=settings.SSO_CLAVE_COMPARTIDA,
            salt="sso-atrasos-docentes",
            max_age=60,
        )
    except signing.BadSignature:
        return redirect("/login/?next=/")
    except signing.SignatureExpired:
        return redirect("/login/?next=/")
    except Exception:
        return redirect("/login/?next=/")

    username = (datos.get("username") or "").strip()
    nombre = (datos.get("nombre") or "").strip()
    rol = (datos.get("rol") or "").strip()

    if not username:
        return redirect("/login/?next=/")

    usuario, creado = User.objects.get_or_create(username=username)

    if creado:
        usuario.set_unusable_password()

    if nombre:
        usuario.first_name = nombre

    usuario.is_staff = True
    usuario.save()

    if rol:
        grupo, _ = Group.objects.get_or_create(name=rol)
        usuario.groups.add(grupo)

    login(request, usuario, backend="django.contrib.auth.backends.ModelBackend")

    if not usuario_tiene_rol_permitido(usuario):
        return redirect("acceso_denegado")

    return redirect("/")


def cerrar_sesion(request):
    logout(request)
    request.session.flush()
    return redirect("http://127.0.0.1:8000/logout/")


def obtener_estado_global(total_registros, total_atrasos, promedio_atraso, top_docentes):
    if total_registros <= 0:
        return "Controlado"

    porcentaje_atrasos = (total_atrasos / total_registros) * 100 if total_registros else 0
    hay_impacto_alto = any((item.get("semaforo") == "alto") for item in top_docentes)

    if hay_impacto_alto or porcentaje_atrasos >= 15 or promedio_atraso >= 20:
        return "Crítico"

    if top_docentes or porcentaje_atrasos >= 5 or promedio_atraso >= 10:
        return "Atención"

    return "Controlado"


def numero_seguro(valor):
    try:
        if valor is None or valor == "":
            return 0
        return float(valor)
    except (TypeError, ValueError):
        return 0


def impacto_docente(cantidad, minutos):
    if minutos >= 120 or cantidad >= 20:
        return "Alto"
    if minutos >= 60 or cantidad >= 10:
        return "Medio"
    return "Bajo"


def construir_ranking_para_pdf(detalle, criterio_orden="cantidad"):
    """
    Replica EXACTAMENTE la lógica que manda la pantalla:
    - solo minutos_atraso > 0
    - agrupa por docente
    - calcula impacto
    - excluye impacto bajo
    - ordena por cantidad o minutos
    - top 5
    - agrega programa predominante para el PDF
    """
    resumen = {}
    programas_por_docente = {}

    for item in detalle:
        docente = str(item.get("docente") or "").strip()
        programa = str(item.get("programa_estudio") or "").strip()
        minutos = numero_seguro(item.get("minutos_atraso"))

        if not docente:
            continue

        if minutos <= 0:
            continue

        if docente not in resumen:
            resumen[docente] = {
                "docente": docente,
                "cantidad": 0,
                "minutos": 0,
            }

        resumen[docente]["cantidad"] += 1
        resumen[docente]["minutos"] += int(round(minutos))

        if docente not in programas_por_docente:
            programas_por_docente[docente] = []

        if programa:
            programas_por_docente[docente].append(programa)

    lista = []

    for docente, datos in resumen.items():
        impacto = impacto_docente(datos["cantidad"], datos["minutos"])

        if impacto == "Bajo":
            continue

        semaforo = "medio"
        semaforo_texto = "Impacto medio"

        if impacto == "Alto":
            semaforo = "alto"
            semaforo_texto = "Alto impacto"

        programa_predominante = "-"
        programas = programas_por_docente.get(docente, [])
        if programas:
            programa_predominante = Counter(programas).most_common(1)[0][0]

        lista.append({
            "docente": docente,
            "programa": programa_predominante,
            "cantidad": datos["cantidad"],
            "minutos": datos["minutos"],
            "impacto": impacto,
            "semaforo": semaforo,
            "semaforo_texto": semaforo_texto,
        })

    if criterio_orden == "minutos":
        lista.sort(key=lambda x: (-x["minutos"], -x["cantidad"], x["docente"]))
    else:
        lista.sort(key=lambda x: (-x["cantidad"], -x["minutos"], x["docente"]))

    return lista[:5]


def normalizar_insights_para_pdf(insights):
    salida = []

    for item in insights:
        if isinstance(item, dict):
            titulo = str(item.get("titulo", "")).strip()
            texto = str(item.get("texto", "")).strip()

            if titulo and texto:
                salida.append(f"{titulo}: {texto}")
            elif texto:
                salida.append(texto)
            elif titulo:
                salida.append(titulo)

        elif isinstance(item, str):
            texto = item.strip()
            if texto:
                salida.append(texto)

    return salida


@acceso_restringido_atrasos
def inicio(request):
    contexto = {}
    criterio_orden = "cantidad"

    if request.method == "POST":
        archivo = request.FILES.get("archivo")
        criterio_orden = request.POST.get("criterio_orden", "cantidad")

        if not archivo:
            contexto["error"] = "Debe seleccionar un archivo Excel."
            contexto["criterio_orden"] = criterio_orden
            return render(request, "atrasos/inicio.html", contexto)

        try:
            resultado = analizar_excel_en_memoria(
                archivo=archivo,
                criterio_orden=criterio_orden
            )

            total_registros = resultado.get("total_registros", 0)
            total_atrasos = resultado.get("total_atrasos", 0)
            promedio_atraso = resultado.get("promedio_atraso", 0)
            top_docentes = resultado.get("top_docentes", [])
            detalle = resultado.get("detalle", [])
            insights = resultado.get("insights", [])

            porcentaje_atrasos = round((total_atrasos / total_registros) * 100, 1) if total_registros else 0
            estado_global = obtener_estado_global(
                total_registros=total_registros,
                total_atrasos=total_atrasos,
                promedio_atraso=promedio_atraso,
                top_docentes=top_docentes
            )

            # 🔥 El PDF ahora toma el ranking con la MISMA lógica que la pantalla
            top_docentes_pdf = construir_ranking_para_pdf(
                detalle=detalle,
                criterio_orden=criterio_orden
            )
            insights_pdf = normalizar_insights_para_pdf(insights)

            contexto["mensaje"] = (
                f"Archivo procesado correctamente. "
                f"Se analizaron {total_registros} registros sin guardar en la base de datos."
            )

            contexto["total_registros"] = total_registros
            contexto["total_atrasos"] = total_atrasos
            contexto["total_a_tiempo"] = resultado.get("total_a_tiempo", 0)
            contexto["total_sin_retiro"] = resultado.get("total_sin_retiro", 0)
            contexto["total_sin_bloque"] = resultado.get("total_sin_bloque", 0)
            contexto["promedio_atraso"] = promedio_atraso
            contexto["top_docentes"] = top_docentes
            contexto["detalle"] = detalle
            contexto["insights"] = insights
            contexto["criterio_orden"] = resultado.get("criterio_orden", criterio_orden)
            contexto["detalle_json"] = detalle

            request.session["analisis_atrasos"] = {
                "archivo": archivo.name,
                "estado_global": estado_global,
                "total_registros": total_registros,
                "total_atrasos": total_atrasos,
                "porcentaje_atrasos": porcentaje_atrasos,
                "promedio_atraso": promedio_atraso,
                "criterio_orden": criterio_orden,
                "top_docentes_pdf": top_docentes_pdf,
                "insights_pdf": insights_pdf,
            }

        except Exception as error:
            contexto["error"] = f"Ocurrió un error al procesar el archivo: {error}"
            contexto["criterio_orden"] = criterio_orden

    else:
        contexto["criterio_orden"] = criterio_orden

    return render(request, "atrasos/inicio.html", contexto)


def generar_reporte_pdf(request):
    datos = request.session.get("analisis_atrasos")

    if not datos:
        return HttpResponse("No hay datos para generar el reporte.", status=400)

    estado_global = datos.get("estado_global", "Controlado")

    clase_estado = "estado-controlado"
    if estado_global == "Crítico":
        clase_estado = "estado-critico"
    elif estado_global == "Atención":
        clase_estado = "estado-atencion"

    contexto = {
        "fecha": datetime.now().strftime("%d-%m-%Y %H:%M"),
        "archivo": datos.get("archivo", "Sin nombre"),
        "estado_global": estado_global,
        "clase_estado": clase_estado,
        "total_registros": datos.get("total_registros", 0),
        "total_atrasos": datos.get("total_atrasos", 0),
        "porcentaje_atrasos": datos.get("porcentaje_atrasos", 0),
        "promedio_atraso": datos.get("promedio_atraso", 0),
        "top_docentes": datos.get("top_docentes_pdf", []),
        "insights": datos.get("insights_pdf", []),
        "acciones_sugeridas": [
            "Priorizar seguimiento sobre docentes con mayor recurrencia y minutos acumulados.",
            "Revisar patrones de atraso en los casos con impacto medio o alto.",
            "Dar trazabilidad específica a registros sin retiro o con observaciones relevantes.",
        ],
    }

    pdf = generar_pdf_reporte(contexto)

    if not pdf:
        return HttpResponse("No fue posible generar el PDF.", status=500)

    response = HttpResponse(pdf, content_type="application/pdf")
    response["Content-Disposition"] = 'attachment; filename="reporte_atrasos.pdf"'
    return response