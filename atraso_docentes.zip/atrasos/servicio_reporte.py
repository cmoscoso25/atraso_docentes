from io import BytesIO

from django.template.loader import render_to_string
from xhtml2pdf import pisa


def generar_pdf_reporte(contexto):
    html = render_to_string("atrasos/reporte_pdf.html", contexto)

    resultado = BytesIO()

    pdf = pisa.CreatePDF(
        src=html,
        dest=resultado,
        encoding="utf-8"
    )

    if pdf.err:
        return None

    return resultado.getvalue()